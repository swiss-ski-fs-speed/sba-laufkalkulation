# PROJEKT-STATUS: SBA Laufkalkulation

Stand: 6. Oktober 2026 · Autor der Übergabe: Claude (bisheriger Account von
Michael Pleus, michael.pleus@swiss-ski.ch, Swiss-Ski)

Dieses Dokument ist der vollständige Projektkontext, damit eine neue
Claude-Session (oder eine Person) das Projekt ohne Rückfragen weiterführen
kann. Alles Wesentliche – Fachlogik, Architektur, Entscheide, offene Punkte,
Termine – steht hier.

---

## 1. Worum es geht

**Snowboard Alpin (SBA), Parallel-Disziplinen PGS/PSL:** In der Qualifikation
fahren die Athlet:innen zwei parallele Kurse (Blau/Rot). Die Coaches wollen
während des Rennens wissen, **welcher Kurs tendenziell der schnellere ist**
(Kernaussage!), um Taktik und Kurswahl zu steuern. Früher wurde das von Hand
in einem Excel gerechnet; heute ist es eine Web-App mit Live-Verteilung an
die Coaches. Das Go-Live hat der Chefcoach freigegeben.

**Beteiligte:**
- **Michael Pleus** (Swiss-Ski) – Projektleitung, Fachlogik.
- **Luca** – hat die Basis-App gebaut (GitHub-Repo `sba-laufkalkulation`,
  mit Michael geteilt), kennt die Firebase- und Login-Passwörter.
- **Mägä** – betreibt das Datensystem (Google BigQuery Data Hub) mit den
  Laufzeiten in Echtzeit. Er wollte die Verknüpfung zur App machen –
  **Status offen**, aktuell läuft stattdessen der FIS-Weg (siehe unten).
  WICHTIG: Sein System darf **nur lesend** angezapft werden, nie schreibend –
  Michael will maximale Unabhängigkeit.
- **Chefcoach** – hat das Projekt zum Live-Schalten freigegeben; seine zwei
  Auflagen (FIS-Livedaten-Anbindung, prägnantere Kernaussage) sind umgesetzt.

## 2. Die App (GitHub-Repo `sba-laufkalkulation`, eine Datei `index.html`)

Lokal bei Michael: `Dokumente/GitHub/sba-laufkalkulation` (GitHub Desktop;
Workflow: Claude ändert Dateien, Michael committed/pusht, Luca zieht).

- **Single-File-Web-App** (Vanilla JS, kein Build), Swiss-Ski-Look (dunkelrot),
  mobile-first.
- **Rollen/Login:** «Command Center» (cc, bearbeiten; Login via Firebase Auth,
  Konto `command-center@sba.app`) und «Coach» (nur lesen; Passwort wird im
  Client gegen SHA-256-Hash geprüft). Passwörter kennt Luca.
- **Live-Sync:** Firebase Realtime Database, Projekt `sba-laufkalkulation`,
  `https://sba-laufkalkulation-default-rtdb.europe-west1.firebasedatabase.app`,
  Pfad `/state`. Der komplette App-Zustand (Events → Läufe Q1/Q2 → Frauen/
  Männer → Kurs blau/rot → Liste {name, zeit}) liegt dort; die App hört per
  WebSocket zu. Fallback: eingebetteter Demo-Zustand im `<script id="appstate">`.
- **Erfassung:** Command Center tippt Zeiten (Modus «Zeit» oder «Diff» wie im
  Excel); Events anlegen/duplizieren/löschen; zusätzliche Läufe (Q3/Finale)
  möglich. Beim Anlegen: Schnellauswahl aus dem FIS-Weltcup-Kalender 2026/27
  (12 Events, Konstante `FIS_WC_2627` in index.html).
- **Coach-Ansicht:** Event-Wahl, Segmente Frauen/Männer/Übersicht. Pro Lauf
  eine Karte mit **grossem Farb-Banner als Kernaussage** («BLAU schneller ·
  0.32 s», vollflächig in Kursfarbe; ⚠-Badge bei instabiler Tendenz; «Noch
  offen» bei zu wenig Daten), darunter die Zeiten beider Kurse. Übersicht:
  vier grosse Farbkacheln (Q1/Q2 × F/M) + Tabelle.

## 3. Fachlogik (Referenz: Excel `_TEMPLATE_SBA.xlsx`, bei Michael)

Alles in `index.html` implementiert und gegen die Excel-Beispieldaten
(Cortina 13.12.2025) auf 3 Nachkommastellen verifiziert:

- **Excel-Methode (Hauptansicht):** Pro Lauf (Q1/Q2) und Geschlecht, pro Kurs
  die Zeiten aufsteigend; `Mean(k)` = kumulativer Durchschnitt der besten k
  Zeiten; **Δ(k) = Mean Blau − Mean Rot**. Verdikt = Vorzeichen von Δ auf der
  vollen Tiefe: **negativ = Blau schneller**. Im Excel: Frauen Top 5, Männer
  Top 8; die App rechnet mit min(Anzahl Blau, Anzahl Rot), praktisch dasselbe.
  **Entscheid Michael: KEIN Schwellenwert** – allein das Vorzeichen zählt
  («ausgeglichen» nur bei praktisch exakt 0).
- **Paarvergleich (Zusatz-Kennzahl, ab Q2):** Jede:r fährt beide Kurse (Q1 auf
  einem, Q2 auf dem anderen). Pro Athlet:in d = Zeit(Blau) − Zeit(Rot) →
  Fahrerstärke kürzt sich raus. Crossover-Korrektur: Gruppe A (Blau zuerst):
  d = C − ΔR; Gruppe B (Rot zuerst): d = C + ΔR. Mit Medianen:
  **Kurs-Effekt C = (med(dA)+med(dB))/2**, **Lauf-Effekt ΔR = (med(dB)−med(dA))/2**
  (positiv = 2. Lauf langsamer). Median = robust gegen Fehlerläufe. Anzeige
  mit «X von Y auf Blau schneller» und aufklappbarer Paar-Tabelle.
  Verifiziert mit konstruiertem Testfall (bekannte Effekte exakt rekonstruiert).
- **Stabilität:** stable = Δ hat auf allen Rangtiefen (min. 3) dasselbe
  Vorzeichen. Bei false: ⚠ «instabil» im Banner/Analyse.

## 4. Automatische Datenzufuhr: Ordner `live-abruf/` im Repo

Eigene kleine Netlify-Site (Base directory `live-abruf`), zwei Scheduled
Functions, beide **nur an Renntagen** aktiv (eingebauter Kalender), beide
schreiben als «automatisches Command Center» in die Firebase (Login mit dem
CC-Konto). Details und Einrichtung: `live-abruf/README.md` (gut gepflegt!).

- **`functions/poller.js`** (jede Minute): sucht die FIS-**Live**-Seite des
  laufenden Rennens (live.fis-ski.com), parst Zeiten, schreibt sie live.
  Hintergrund: Es gibt KEINE öffentliche FIS-Live-API; die Live-Seiten werden
  vom Zeitmessungs-XML-Feed gespiesen. Der Parser ist generisch gebaut und
  wird per Logs am echten Event geschärft (deshalb die Generalprobe, unten).
- **`functions/pdf-poller.js`** (alle 5 Min.): holt die offiziellen Quali-PDFs
  (Startlisten mit Kurszuteilung blau/rot pro Startnummer; Resultatlisten
  Run 1/2) über das FIS-Adressmuster
  `data.fis-ski.com/pdf/<Saison>/SB/<Codex>/...`, verknüpft Kurs+Zeit und
  schreibt sie – robuste zweite Quelle, Zeiten kurz nach Laufende.
- **Sicherheitsnetze (beide):** Es werden nur Events mit `auto:true`
  angefasst (die die Automatik selbst angelegt hat) – manuelle Events sind
  tabu, manuelle Erfassung bleibt voller Fallback. Nie mit «leer»
  überschreiben. `DRY_RUN=1` = nur loggen. `FORCE=1` = Renntag-Check umgehen.
- **Umgebungsvariablen:** `CC_PASSWORD` (Pflicht, geheim), optional
  `CC_EMAIL`, `FB_API_KEY`, `FB_DB_URL` (Defaults = Werte der App),
  `LIVE_URL`, `DRY_RUN`, `FORCE`, `TEST_RACE`.
- **Testmöglichkeiten (alle dokumentiert im README):**
  1. Mock-Test: `LIVE_URL` auf `<site>/mock-live.json` + `FORCE=1` → ganze
     Kette bis in die App (Event «TEST» erscheint; danach löschen).
  2. PDF-Test mit echten Daten der letzten Saison:
     `TEST_RACE=2026:6169` (Cortina-Quali 13.12.2025) + `FORCE=1` + `DRY_RUN=1`
     → Logs zeigen gefundene PDFs/Kurse/Zeiten; Parser danach schärfen.
  3. Generalprobe Sölden (siehe Termine).

## 5. Termine & offene Punkte (chronologisch)

- **Status Tests mit Luca:** Michael wollte Mock- und PDF-Test mit Luca
  machen – Stand beim Übergabezeitpunkt unklar, nachfragen.
- **24./25. Okt. 2026 – Generalprobe Sölden** (Ski-Alpin-Auftakt, Damen-RTL
  Sa, Herren-RTL So, Läufe ca. 10:00/13:00): `FORCE=1` + `DRY_RUN=1` setzen;
  der Live-Poller loggt die echte FIS-Live-Datenstruktur. **Logs kopieren und
  Claude geben → Live-Parser `parseLive()` in poller.js anhand der echten
  Struktur fertig schärfen.** Danach FORCE entfernen. (Erinnerung dafür ist
  im ALTEN Account auf 23.10., 9:00 eingerichtet.)
- **28./29. Nov. 2026 – Snow Ruyi (CHN), erstes Saisonrennen:** Erster
  Ernstfall der Automatik, anfangs mit `DRY_RUN=1` verifizieren, dann scharf.
- **Danach:** `DRY_RUN` entfernen; App-Link + Passwörter an Coaches (macht
  Luca/Michael).
- **Offen / Nice-to-have:**
  - FIS-Event-IDs für Snow Ruyi, Mylin, Ratschings in `pdf-poller.js`
    (KALENDER, Feld `eventid: null`) nachtragen, sobald im FIS-Kalender
    verfügbar (event-details.html?eventid=...).
  - Mägä/BigQuery-Anbindung als dritte Quelle (er wollte die Verknüpfung
    machen; nur lesend!). Ein früherer eigener Prototyp (Netlify +
    BigQuery-Function, «kurskalkulation-sba») existiert als ZIP bei Michael
    («Maegae-Uebergabe.zip»), wurde aber zugunsten von Lucas App zurückgestellt.
  - Ideen-Backlog (vom Coaches-Feedback abhängig): SUI-Athleten hervorheben,
    Δ-Verlauf über Startnummern (wird ein Kurs langsamer?), Duell-Vorschau
    für Finals, Saison-Archiv, PDF-Export fürs Debriefing, FIS-Punkte/
    Startlisten vorab.

## 6. Arbeitsweise / Konventionen

- Alle Claude-Ergänzungen im Code sind mit `Ergänzung Michael/Claude`
  kommentiert; Lucas Kern unangetastet lassen.
- Änderungen an Michaels lokalem Repo-Ordner machen, er committed/pusht via
  GitHub Desktop (Diff als Review für Luca).
- Externe Systeme (Mägä, FIS): strikt nur lesend.
- Sprache im Projekt: Deutsch (Schweiz), Anzeige-Konvention überall:
  **Δ = Blau − Rot, negativ = Blau schneller.**
