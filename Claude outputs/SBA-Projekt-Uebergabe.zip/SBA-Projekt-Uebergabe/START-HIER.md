# START HIER – Projekt im neuen Account weiterführen

Dieses Paket enthält alles, um das Projekt **SBA Laufkalkulation** mit einem
neuen Claude-Account nahtlos weiterzuführen (Stand: 6. Oktober 2026).

## So geht's im neuen Account

1. Neue Cowork-Konversation starten.
2. Dieses ZIP hochladen (oder den entpackten Ordner verbinden).
3. Claude schreiben:

   > «Lies PROJEKT-STATUS.md – das ist der komplette Stand meines Projekts
   > SBA Laufkalkulation. Wir führen es von dort weiter.»

4. Zusätzlich den GitHub-Ordner verbinden («Ordner hinzufügen» →
   `Dokumente/GitHub/sba-laufkalkulation`), damit Claude direkt am aktuellen
   Code arbeiten kann. Der Code im Unterordner `projekt/` hier ist nur ein
   Schnappschuss – die Wahrheit liegt im GitHub-Repository.

## Inhalt

- `PROJEKT-STATUS.md` – Das Wichtigste: kompletter Projektkontext für Claude
  (Was, Wie, Warum, alle Entscheide, offene Punkte, Termine).
- `projekt/` – Schnappschuss des Codes vom 6.10.2026 (App + Live-Abruf),
  identisch mit dem GitHub-Stand.

## Nicht im Paket (bewusst)

- **Passwörter/Secrets** (Command-Center-Passwort, Coach-Passwort,
  Firebase-Zugänge): kennt Luca bzw. liegen in Netlify als
  Umgebungsvariablen. Gehören nicht in ein Dokument.
- **Excel-Vorlage `_TEMPLATE_SBA.xlsx`**: hast du; die Rechenlogik daraus ist
  in PROJEKT-STATUS.md vollständig dokumentiert und 1:1 in der App umgesetzt.
- **Geplante Erinnerung** (Generalprobe Sölden, 23.10., 9:00): Die ist an den
  alten Account gebunden. Da das Abo bis 4.11. läuft, feuert sie noch im
  alten Account – danach im neuen Account bei Bedarf neu einrichten.
